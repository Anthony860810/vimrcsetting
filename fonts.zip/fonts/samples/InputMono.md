#InputMono
![](https://cloud.githubusercontent.com/assets/8317250/7021760/2240b122-dd60-11e4-9314-6aad9f5df2a6.png)
